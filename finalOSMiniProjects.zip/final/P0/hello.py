#!/usr/bin/python

def main():
  # Make this function print the phrase "Hello, World!" without quotes.  
  print "Hello, World!"

if __name__ == '__main__':
  main()
