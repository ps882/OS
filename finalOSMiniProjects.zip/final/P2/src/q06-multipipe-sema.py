from rvr import MP, MPthread
import random

# Q06:
#    Complete the implementation of the MultiPurposePipe monitor below using
#    MPsema. Your implementation should be able to make progress if there are 
#    liquids that can flow

################################################################################
## DO NOT WRITE OR MODIFY ANY CODE ABOVE THIS LINE #############################
################################################################################

class MultiPurposePipe(MP):
    """
    California has encountered another water crisis requiring new pipes to be
    built. The governor has decided to cut costs and introduce a new technology:
    multi-purpose pipes.  These pipes alternate carrying clean water and sewage.

    You are the lone civil engineer at the control station, and it is your job
    to make sure that people don't drink sewage. The multi-purpose pipe allows
    multiple instances of liquid to pass through in its respective direction.
    And at any point in time, the liquid flowing through must be of the same type.
    Specifically in this problem, CleanWater threads will be flowing in direction 1, 
    while Sewage threads will be flowing in direction 0.

    Liquids wishing to flow should call the flow(), and once they have finished
    flowing, they should call finished()
    """

    def __init__(self):
        MP.__init__(self)
        self.sewFlow = self.Semaphore("sewerage flow control handle",1)      #semaphore to control sewage flow
        self.cleanFlow = self.Semaphore("clean flow control handle",1)       #semaphore to control clean flow
        self.waitFlow = self.Semaphore("Only one flow at a time",1)          #semaphore to control only one kind of flow, like a baton
        self.debug = True
#
        self.cleanCount = self.Shared("Count of clean liquid flowing",0)   
        self.sewCount = self.Shared("Count of sewage liquid flowing",0)   

    def flow(self, direction):
        """wait for permission to flow through the pipe. direction should be
        either 0 or 1."""

        if direction == 1:                                              #if clean water thread
            self.cleanFlow.procure()                                    #make sure no other clean water thread goes through by procuring the lock

            self.cleanCount.inc()                                       #increment total liquid thread count
            if self.cleanCount.read() == 1:
                self.waitFlow.procure()                                 #if you are the first thread, then try and procure the baton

            self.cleanFlow.vacate()                                     #if have baton then pass and release the mutex else you and subsequent threads would be waiting until baton is released

        if direction == 0:                                             
            self.sewFlow.procure()                                    

            self.sewCount.inc()                                      
            if self.sewCount.read() == 1:
                self.waitFlow.procure()

            self.sewFlow.vacate()

      # TODO
        pass

    def finished(self,direction):
        self.direction = direction

        if direction == 1:                                              #if clean water thread
            self.cleanFlow.procure()                                    #make sure no other clean water thread goes through by procuring the lock

            self.cleanCount.dec()                                       #decrement total liquid thread count
            if self.cleanCount.read() == 0:
                self.waitFlow.vacate()                                  #if you are the last threads, then release the baton and other threads could grab it then

            self.cleanFlow.vacate()                                     #vacate the clean water mutex

        if direction == 0:                                        
            self.sewFlow.procure()                               

            self.sewCount.dec()                                 
            if self.sewCount.read() == 0:
                self.waitFlow.vacate()

            self.sewFlow.vacate()
       # TODO
        pass

################################################################################
## DO NOT WRITE OR MODIFY ANY CODE BELOW THIS LINE #############################
################################################################################


class Sewage(MPthread):
    def __init__(self, pipe, name, id):
        MPthread.__init__(self, pipe, name)
        self.direction = 0
        self.wait_time = random.uniform(0.1,0.5)
        self.pipe      = pipe
        self.id        = id

    def run(self):
        # flush
        self.delay(self.wait_time)
        print "Sewage %d: trying to flow" % (self.id)
        # request permission to flow
        self.pipe.flow(self.direction)
        print "Sewage %d: Flowing" % self.id
        # flow through
        self.delay(0.01)
        print "Sewage %d: Flowed" % self.id
        # signal that we have finished flowing
        self.pipe.finished(self.direction)
        print "Sewage %d: Finished flowing" % self.id

class CleanWater(MPthread):
    def __init__(self, pipe, name, id):
        MPthread.__init__(self, pipe, name)
        self.direction = 1
        self.wait_time = random.uniform(0.1,0.5)
        self.pipe      = pipe
        self.id        = id

    def run(self):
        # turn on faucet
        self.delay(self.wait_time)
        print "CleanWater %d: Trying to flow" % (self.id)
        # request permission to flow
        self.pipe.flow(self.direction)
        print "CleanWater %d: Flowing" % self.id
        # flow through
        self.delay(0.01)
        print "CleanWater %d: Flowed" % self.id
        # signal that we have finished flowing
        self.pipe.finished(self.direction)
        print "CleanWater %d: Finished flowing" % self.id


if __name__ == "__main__":

    cityPipe = MultiPurposePipe()
    sid = 0
    cid = 0
    for i in range(100):
        if random.randint(0, 1) == 0:
            Sewage(cityPipe, 'Sewage thread' + str(sid), sid).start()
            sid += 1
        else:
            CleanWater(cityPipe, 'CleanWater thread' + str(cid), cid).start()
            cid += 1


    cityPipe.Ready()
