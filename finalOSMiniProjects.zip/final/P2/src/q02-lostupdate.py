from rvr import MP, MPthread

# Q02:
# This program simulates a game between two teams.  Each team
# presses their button as fast as they can.  There is a counter that starts at
# zero; the red team's button increases a counter, while the blue team's button
# decreases the counter.  They each get to press their button 10000 times. If the
# counter ends up positive, the read team wins; a negative counter means the blue
# team wins.
#
# a. This game is boring: it should always end in a draw.  However, the provided
#    implementation is not properly synchronized.  When both threads terminate,
#    what are the largest and smallest possible scores?
#
#ANS
# Maximum value can be 10000 and smallest value can be -10000
#
# b. What other values can the score have when both threads have terminated?
#
#ANS
# Any score from 10000 to -10000 is possible depending on scheduling. When i ran the code i got -444,1286,324,3 etc.
#
# c. Add appropriate synchronization such that updates to the counter
#    occur in a critical section, ensuring that the energy level is
#    always at 0 when the two threads terminate.
#
#    Your synchronization must still allow interleaving between the two threads.
#     
#    (Now would be a good time to go read the file rvr.md in your docs folder.
#     It will explain how to use a variety of synchronization primitives supported
#     by the 4410 Synchronization Library, which must be exclusively used for this
#     entire assignment.)

class Contest(MP):
    def __init__(self):
        MP.__init__(self)
        self.counter = self.Shared("counter", 0)
        self.buttonlock  = self.Lock("monitor lock")

    def pushRed(self):
        with self.buttonlock:
            #print str(self.counter.read()) + "from push red"
            self.counter.inc()

    def pushBlue(self):
        with self.buttonlock:
            #print str(self.counter.read()) + "from push blue"
            self.counter.dec()

class RedTeam(MPthread):
    def __init__(self, contest):
        MPthread.__init__(self, contest, "Red Team")
        self.contest = contest     

    def run(self):
        for i in range(10000):
            self.contest.pushRed()

class BlueTeam(MPthread):
    def __init__(self, contest):
        MPthread.__init__(self, contest, "Blue Team")
        self.contest = contest

    def run(self):
        for i in range(10000):
            self.contest.pushBlue()


################################################################################
## DO NOT WRITE OR MODIFY ANY CODE BELOW THIS LINE #############################
################################################################################

contest = Contest()
red  = RedTeam(contest)
blue = BlueTeam(contest)
red.start()
blue.start()
contest.Ready()

print("The counter is " + str(contest.counter.read()))
