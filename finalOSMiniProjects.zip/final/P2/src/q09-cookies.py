﻿from rvr import MP, MPthread
import random

# Q09:
# This program simulates the creation of chocolate chip cookies.
#
# Implement the CookieMonitor monitor below using MPlocks and
# MPcondition variables.
#NOTE: Inspiration for this solution taken from H2O synchronization problem
################################################################################
## DO NOT WRITE OR MODIFY ANY CODE ABOVE THIS LINE #############################
################################################################################

class CookieMonitor(MP):
    """
    A chocolate chip cookie is made from one chocolate and three cookie dough (each
    chocolate and cookie dough can be used in only one cookie).  A thread offers an
    ingredient by calling the appropriate method; the thread will block until
    the ingredient can be used in the cookie.
    """

    def __init__(self):
        MP.__init__(self)
        self.mp_lock = self.Lock("monitor lock")
        self.nCookie = self.Shared("no of cookies available",0)
        self.nChoc = self.Shared("no of chocolate available",0)
        self.lCookie = self.Shared("no of cookies left",0)
        self.lChoc = self.Shared("no of chocolate leaving",0)
#        self.debug = True
#
        self.cookieWaiting = self.mp_lock.Condition("conditioned on whether all cookies have arrived")
        self.chocWaiting = self.mp_lock.Condition("conditioned on whether the choc have arrived")
        # TODO
        pass


    def chocolate_ready(self):
        """Offer a chocolate and block until this chocolate can be used to make
        a cookie."""
        with self.mp_lock:
           self.nChoc.inc()
           while self.lChoc.read() == 0:                                  #if cookies from last batch have left i.e. cookies set to leave = 0
               if self.nChoc.read() >= 1 and self.nCookie.read() >= 3:    #look for new batch of 3 cookies + 1 choc, if found
                   self.nCookie.dec(3)                                    #dec number of present cookies and choc, inc the number of cookies and choc set to leave 
                   self.nChoc.dec(1)
                   self.lChoc.inc(1)
                   self.lCookie.inc(3)
                   self.cookieWaiting.signal()                            #signal other mates from this batch, so that they can also leave
                   self.cookieWaiting.signal()
                   self.cookieWaiting.signal()
               else:
                   self.cookieWaiting.wait()

           self.lChoc.dec(1)                                              #if leaving cookies are not 0 yet, then allow new/old cookies to pass until it becomes 0
        # TODO
        pass

    def cookie_dough_ready(self):
        """Offer a cookie dough and block until this cookie dough can be used to make a
        cookie."""
        with self.mp_lock:
           self.nCookie.inc()
           while self.lCookie.read() == 0:
               if self.nChoc.read() >= 1 and self.nCookie.read() >= 3:
                   self.nCookie.dec(3)
                   self.nChoc.dec(1)
                   self.lChoc.inc(1)
                   self.lCookie.inc(3)
                   self.cookieWaiting.signal()
                   self.cookieWaiting.signal()
                   self.chocWaiting.signal()
               else:
                   self.chocWaiting.wait()

           self.lCookie.dec(1)
       # TODO
        pass

################################################################################
## DO NOT WRITE OR MODIFY ANY CODE BELOW THIS LINE #############################
################################################################################

class Chocolate(MPthread):
    def __init__(self, cookie, id):
        MPthread.__init__(self, cookie, id)
        self.cookie = cookie
        self.id = id

    def run(self):
        while True:
            print "Chocolate %d ready" % self.id
            self.cookie.chocolate_ready()
            print "Chocolate %d is in the oven" % self.id
            self.delay()
            print "Chocolate %d finished baking" % self.id

class CookieDough(MPthread):
    def __init__(self, cookie, id):
        MPthread.__init__(self, cookie, id)
        self.cookie = cookie
        self.id = id

    def run(self):
        while True:
            print "CookieDough %d ready" % self.id
            self.cookie.cookie_dough_ready()
            print "CookieDough %d is in the oven" % self.id
            self.delay(0.5)
            print "CookieDough %d finished baking" % self.id

if __name__ == '__main__':
    NUM_CHOCOLATE = 5
    NUM_COOKIEDOUGH = 6

    c = CookieMonitor()

    for i in range(NUM_CHOCOLATE):
        Chocolate(c, i).start()

    for j in range(NUM_COOKIEDOUGH):
        CookieDough(c, j).start()

    c.Ready()
