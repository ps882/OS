#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ifaddrs.h>
#include <poll.h>
#include <fcntl.h>
#include <errno.h>
#include "global.h"

/* Information about files and sockets is kept here.  An outgoing
 * connection is one requested by the local user using the 'C'
 * command.  An incoming connection is one created by a remote user.
 * We don't try to re-establish incoming connections after they break.
 */
/*struct file_info {
    struct file_info *next;                     // linked list management
    char *uid;                                  // unique connection id
    int fd;                                     // file descriptor
    enum file_info_type {
        FI_FREE,                            // unused entry
        FI_FILE,                            // file descriptor, probably stdin
        FI_SERVER,                          // server socket
        FI_INCOMING,                        // incoming connection
        FI_OUTGOING,                        // outgoing connection
    } type;                                     // type of file
    enum { FI_UNKNOWN, FI_KNOWN } status;       // is the peer address known?
    struct sockaddr_in addr;                    // address of peer if known
    void (*handler)(struct file_info *, int events);        // event handler`
    int events;                                 // POLLIN, POLLOUT
    char *input_buffer;                         // stuff received
    int amount_received;                        // size of input buffer
    char *output_buffer;                        // stuff to send
    int amount_to_send;                         // size of output buffer
    union {
        struct fi_outgoing {
            enum { FI_CONNECTING, FI_CONNECTED } status;
            double connect_time;            // time of last attempt to connect
        } fi_outgoing;
    } u;
};
*/
struct file_info *file_info;
int nfiles;
char *uid_gen = (char *) 1;

struct sockaddr_in my_addr;

/* Add file info about 'fd'.
 */
static struct file_info *file_info_add(enum file_info_type type, int fd,
                        void (*handler)(struct file_info *, int events), int events){
    //printf("DEBUG: file_info_add : begin\n");
    struct file_info *fi = calloc(1, sizeof(*fi));
    fi->uid = uid_gen++;
    fi->type = type;
    fi->fd = fd;
    fi->handler = handler;
    fi->events = events;
    fi->next = file_info;
    file_info = fi;
    nfiles++;
    return fi;
}

/* Destroy a file_info structure.
 */
static void file_info_delete(struct file_info *fi){
    //printf("DEBUG: file_info_delete : begin\n");
    struct file_info **pfi, *fi2;

    for (pfi = &file_info; (fi2 = *pfi) != 0; pfi = &fi2->next) {
        if (fi2 == fi) {
            *pfi = fi->next;
            break;
        }
    }
    free(fi->input_buffer);
    free(fi->output_buffer);
    free(fi);
}

/* Put the given message in the output buffer.
 */
void file_info_send(struct file_info *fi, char *buf, int size){
    //printf("DEBUG: file_info_send : begin\n");
    fi->output_buffer = realloc(fi->output_buffer, fi->amount_to_send + size);
    memcpy(&fi->output_buffer[fi->amount_to_send], buf, size);
    fi->amount_to_send += size;
}

/* Same as file_info_send, but it's done on sockaddr_in instead of file_info
 */
struct file_info* sockaddr_to_file(struct sockaddr_in dst) {
    //printf("DEBUG: sockaddr_to_file : begin\n");
    struct file_info* fi;
    for (fi = file_info; fi != 0; fi = fi->next) {
        if (addr_cmp(dst, fi->addr) == 0) {
            return fi;
        }
    }
    printf("sockaddr not connected to host");
    return NULL;
}

/* Broadcast to all connections except fi.
 */
void file_broadcast(char *buf, int size, struct file_info *fi){
    //printf("DEBUG: file_broadcast : begin\n");
    struct file_info *fi2;
    for (fi2 = file_info; fi2 != 0; fi2 = fi2->next) {
        if (fi2->type == FI_FREE || fi2 == fi) {
            continue;
        }
        if (fi2->type == FI_OUTGOING && fi2->u.fi_outgoing.status == FI_CONNECTING) {
            continue;
        }
        if (fi2->type == FI_OUTGOING || fi2->type == FI_INCOMING) {
            //printf("DEBUG: file_broadcast: fi type is IN/OUT\n");
            file_info_send(fi2, buf, size);
        }
    }
}

/* This is a timer handler to reconnect to a peer after a period of
   time elapsed.
 */
static void timer_reconnect(void *arg){
    //printf("DEBUG: timer_reconnect : begin\n");
    void try_connect(struct file_info *fi);

    struct file_info *fi;
    for (fi = file_info; fi != 0; fi = fi->next) {
        if (fi->type != FI_FREE && fi->uid == arg) {
            printf("reconnecting\n");
            try_connect(fi);
            return;
        }
    }
    printf("reconnect: entry not found\n");
}

/* The user typed in a C<addr>:<port> command to connect to a peer.
 */
static void connect_command(struct file_info *fi, char *addr_port){
    //printf("DEBUG: connect_command : begin\n");
    void try_connect(struct file_info *fi);

    if (fi->type != FI_FILE) {
        fprintf(stderr, "unexpected connect message\n");
        return;
    }

    char *p = index(addr_port, ':');
    if (p == 0) {
        fprintf(stderr, "do_connect: format is C<addr>:<port>\n");
        return;
    }
    *p++ = 0;

    struct sockaddr_in addr;
    if (addr_get(&addr, addr_port, atoi(p)) < 1) {
        return;
    }
    *--p = ':';

    fi = file_info_add(FI_OUTGOING, -1, 0, 0);
    fi->u.fi_outgoing.status = FI_CONNECTING;

    /* Even though we're connecting, you're allowed to connect using
     *  any address to a peer (including a localhost address).  So we
     *  have to wait for the Hello message until we're certain who it
     *  is on the other side.  Until then, we keep the address we know
     *  for debugging purposes.
     */
    fi->addr = addr;

    try_connect(fi);
}

/* We uniquely identify a socket connection by the lower of the local
 * TCP/IP address and the remote one.  Because two connections cannot
 * share TCP/IP addresses, this should work.
 */
static void get_id(int skt, struct sockaddr_in *addr){
    //printf("DEBUG: get_id : begin\n");
    struct sockaddr_in this, that;
    socklen_t len;

    len = sizeof(that);
    if (getsockname(skt, (struct sockaddr *) &this, &len) < 0) {
        perror("getsockname");
        exit(1);
    }
    len = sizeof(that);
    if (getpeername(skt, (struct sockaddr *) &that, &len) < 0) {;
        perror("getpeername");
        exit(1);
    }
    *addr = addr_cmp(this, that) < 0 ? this : that;
}

/* Received a H(ello) message of the form H<addr>:<port>.  This is the
 * first message that's sent over a TCP connection (in both
 * directions) so the peers can identify one another.  The port is the
 * server port of the endpoint rather than the connection's port.
 *
 * Sometimes accidentally peers try to connect to one another at the same time.
 * This code kills one of the connections.
 */
void hello_received(struct file_info *fi, char *addr_port){
    //printf("DEBUG: hello_received : begin\n");
    char *p = index(addr_port, ':');
    if (p == 0) {
        fprintf(stderr, "do_hello: format is H<addr>:<port>\n");
        return;
    }
    *p++ = 0;

    struct sockaddr_in addr;
    if (addr_get(&addr, addr_port, atoi(p)) < 1) {
        return;
    }
    *--p = ':';

    printf("Got hello from %s:%d on socket %d\n", inet_ntoa(addr.sin_addr), ntohs(addr.sin_port), fi->fd);

    /* If a connection breaks and is re-established, a duplicate hello
     * message is likely to arrive, but we can ignore it as we already
     * know the peer.
     */
    if (fi->status == FI_KNOWN) {
        fprintf(stderr, "Duplicate hello (ignoring)\n");
        if (addr_cmp(addr, fi->addr) != 0) {
            fprintf(stderr, "do_hello: address has changed???\n");
        }
        return;
    }

    /* It is possible to set up a connection to self.  We deal with it
     * by ignoring the Hello message but keeping the connection
     * established.
     */
    if (addr_cmp(addr, my_addr) == 0) {
        fprintf(stderr, "Got hello from self??? (ignoring)\n");
        return;
    }

    /* Search the connections to see if there is already a connection
     * to this peer.
     */
    struct file_info *fi2;
    for (fi2 = file_info; fi2 != 0; fi2 = fi2->next) {
        if (fi2->type == FI_FREE || fi2->status != FI_KNOWN) {
            continue;
        }
        if (addr_cmp(fi2->addr, addr) != 0) {
            continue;
        }

        /* Found another connection.  We're going to keep just one.
         * First see if this is actually an existing connection.  It
         * may have broken.
         */
        if (fi2->fd == -1) {
            printf("Found a defunct connection---dropping that one\n");
            if (fi2->type == FI_OUTGOING) {
                fi->type = FI_OUTGOING;
                fi->u.fi_outgoing = fi2->u.fi_outgoing;
            }
            fi2->type = FI_FREE;
            return;
        }

        /* Of the two, we keep the "lowest one".  We identify a
         * connection by the lowest endpoint address.
         */
        struct sockaddr_in mine, other;
        get_id(fi->fd, &mine);
        get_id(fi2->fd, &other);
        if (addr_cmp(mine, other) < 0) {
            /* We keep mine.
             */
            printf("duplicate connection -- keep mine\n");
            if (fi2->type == FI_OUTGOING) {
                fi->type = FI_OUTGOING;
                fi->u.fi_outgoing = fi2->u.fi_outgoing;
            }
            close(fi2->fd);
            fi2->type = FI_FREE;
        }
        else {
            printf("duplicate connection -- keep other\n");

            /* The other one wins.
             */
            if (fi->type == FI_OUTGOING) {
                fi2->type = FI_OUTGOING;
                fi2->u.fi_outgoing = fi->u.fi_outgoing;
            }
            close(fi->fd);
            fi->type = FI_FREE;
            return;
        }
    }

    /* No other connection.  Keep this one.
     */
    fi->addr = addr;
    fi->status = FI_KNOWN;

    //updatenodelist with the newly found neighbor and also handle the connection change

    //printf("DEBUG: hello_received :  calling update_nodeList\n");
    update_nodeList(addr_to_string(addr), true, false);
    //printf("DEBUG: hello_received : calling connection_change_handler\n");
    connection_change_handler();
}

/*This function is to handle the sending of messages
 *Logic is to check the destination address and if it yours then print it
 *Else pass it on to the next node capable of handling this message if not found then discard it
 */

void send_received(char *line){
    //printf("DEBUG: send_received : begin\n");
    char *port = index(line, ':');
    int line_len = strlen(line);
    //printf("DEBUG: send_received : line_len = %d\n", line_len);
    //increase line length to adjust for newline character added and space needed for using unsigned long instead of char
    line_len += 5;

    int i;

    if (port == 0) {
        fprintf(stderr, "send_received: format is S<addr>:<port>/TTL/payload\n");
        return;
    }
    *port++ = 0;
    
    char *ttl = index(port, '/');
    if (ttl == 0) {
        fprintf(stderr, "send_received: no TTL\n");
        return;
    }
    *ttl++ = 0;
    
    char *payload = index(ttl, '/');
    if (payload == 0) {
        fprintf(stderr, "do_gossip: no payload\n");
        return;
    }
    *payload++ = 0;
    
    //convert string ttl to integer TTL, IP and port to addr_in address// payload is already in string

    unsigned long ttl_ul = strtoul(ttl, NULL , 10);
    struct sockaddr_in dest_addr;
    if (addr_get(&dest_addr, line, atoi(port)) < 0){
        return;
    }

    //check if addr is for you , if so then print it
    if (addr_cmp(my_addr,dest_addr) == 0){
        printf("%s\n", payload);
        return;
    }

    if (ttl_ul < 1){
        return;
    }

    // if not meant for you and has 1 or more ttl then decrement the ttl and handle it

    ttl_ul--;
    char *modified_line = (char *)malloc(line_len);
    sprintf(modified_line, "S%s/%lu/%s\n", addr_to_string(dest_addr), ttl_ul, payload );
    //printf("DEBUG: send_received : final dest %s:%s, sending message %s\n", line,port,modified_line);
    int self_index = nl_index(networkStructure.nodeList, addr_to_string(my_addr));
    int dest_index = nl_index(networkStructure.nodeList, addr_to_string(dest_addr));
    int next_index = -1;

    for (i=0; i< nl_nsites(networkStructure.nodeList) ; i++){

        if (networkStructure.prev[dest_index] == -1){
            //printf("DEBUG: send_received : could not find the destination to send");
            free(modified_line);
            return;
        }

        if (networkStructure.prev[dest_index] == self_index){
            next_index = dest_index;
            break;
        }
        else{
            dest_index = networkStructure.prev[dest_index];
        }
    }

    if (next_index == -1){
        //printf("DEBUG: send_received : Node not found after nnode iteration");
        free(modified_line);
        return;
    }

    //now that we have index of next node, we need to get the name and address of it
    char *next_addr = nl_name(networkStructure.nodeList, next_index);
    //printf("DEBUG: send_received : found next hop index = %d , address = %s\n", next_index , next_addr);

    //next we need to find the file descriptor for this address and use file_info_send to send the modified_line
    struct file_info *fi;
    for (fi = file_info; fi!=0; fi=fi->next){
        //for each file we need to check if the connection is active and if address matches before sending the data
        //printf("DEBUG: send_received : looking for file handlers\n");
        if ((addr_cmp(fi->addr,string_to_addr(next_addr)) == 0) && (fi->type == FI_INCOMING || (fi->type == FI_OUTGOING && fi->u.fi_outgoing.status == FI_CONNECTED && fi->status == FI_KNOWN)) ){
            //printf("DEBUG: send_received : sending message via file_info_send\n");
            //printf("DEBUG: send_received : modified_line length = %lu , in int = %d \n", strlen(modified_line), (int)(strlen(modified_line)));
            file_info_send(fi, modified_line, strlen(modified_line));
            break;
        }
    }
        //printf("DEBUG: send_received : message sent freeing modified_line\n");
        free(modified_line);
        //printf("DEBUG: send_received : message sent freed modified_line\n");


    
}


/* A line of input (a command) is received.  Look at the first
 * character to determine the type and take it from there.
 */
static void handle_line(struct file_info *fi, char *line){
    //printf("DEBUG: handle_line : begin\n");
    switch (line[0]) {
    case 0:
        break;
    case 'C':
        connect_command(fi, &line[1]);
        break;
    case 'G':
        gossip_received(fi, &line[1]);
        break;
    case 'H':
        hello_received(fi, &line[1]);
        break;
    case 'S':
        send_received(&line[1]);
        break;
    case 'E':
    case 'e':
        exit(0);
        break;
    default:
        fprintf(stderr, "unknown command: '%s'\n", line);
    }
}

void handle_closed_socket(struct file_info *fi){
    //printf("DEBUG: handle_closed_socket : begin\n");
    printf("Lost connection on socket %d\n", fi->fd);

    close(fi->fd);

    /* Start a timer to reconnect if it's an outgoing connection.
     */
    if (fi->type == FI_OUTGOING) {
        double time = timer_now() + 1;
        timer_start(time, timer_reconnect, fi->uid);
        fi->fd = -1;
        fi->u.fi_outgoing.status = FI_CONNECTING;
    }
    else {
        fi->type = FI_FREE;
    }
    //printf("DEBUG: handle_closed_socket : calling connection change, lost connection\n");
    connection_change_handler();
}

/* Input is available on the given connection.  Add it to the input
 * buffer and see if there are any complete lines in it.
 */
static void add_input(struct file_info *fi){
    //printf("DEBUG: add_input : begin\n");
    fi->input_buffer = realloc(fi->input_buffer, fi->amount_received + 100);
    int n = read(fi->fd, &fi->input_buffer[fi->amount_received], 100);
    if (n == 0) {
        handle_closed_socket(fi);
        return;
    }
    if (n < 0) {
        perror("read");
        exit(1);
    }
    if (n > 0) {
        fi->amount_received += n;
        for (;;) {
            char *p = memchr(fi->input_buffer, '\n', fi->amount_received);
            if (p == 0) {
                break;
            }
            *p++ = 0;
            handle_line(fi, fi->input_buffer);
            int n = fi->amount_received - (p - fi->input_buffer);
            memmove(fi->input_buffer, p, n);
            fi->amount_received = n;
            if (fi->fd == 0) {
                printf("> ");
                fflush(stdout);
            }
        }
    }
}

/* Activity on a socket: input, output, or error...
 */
static void message_handler(struct file_info *fi, int events){
    //printf("DEBUG: message_handler : begin\n");
    char buf[512];

    if (events & (POLLERR | POLLHUP)) {
        double time;
        int error;
        socklen_t len = sizeof(error);
        if (getsockopt(fi->fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
            perror("getsockopt");
        }
        switch (error) {
        case 0:
            //printf("DEBUG: message_handler : observed POLERR/HUP event for error 0\n");
            printf("Lost connection on socket %d\n", fi->fd);
            time = timer_now() + 1;
            break;
        default:
            printf("Error '%s' on socket %d\n", strerror(error), fi->fd);
            time = timer_now() + 5;
        }

        close(fi->fd);

        /* Start a timer to reconnect.
         */
        if (fi->type == FI_OUTGOING) {
            timer_start(time, timer_reconnect, fi->uid);
            fi->fd = -1;
            fi->u.fi_outgoing.status = FI_CONNECTING;
        }
        else {
            fi->type = FI_FREE;
        }

        //lost a connection so handle the connection change
        //printf("DEBUG: message_handler : calling connection change, lost connection\n");
        connection_change_handler();

        return;
    }
    if (events & POLLOUT) {
        int n = send(fi->fd, fi->output_buffer, fi->amount_to_send, 0);
        if (n < 0) {
            perror("send");
        }
        if (n > 0) {
            if (n == fi->amount_to_send) {
                fi->amount_to_send = 0;
            }
            else {
                memmove(&fi->output_buffer[n], fi->output_buffer, fi->amount_to_send - n);
                fi->amount_to_send -= n;
            }
        }
    }
    if (events & POLLIN) {
        add_input(fi);
    }
    if (events & ~(POLLIN|POLLOUT|POLLERR|POLLHUP)) {
        printf("message_handler: unknown events\n");
        fi->events = 0;
    }
}

/* Send a H(ello) message to the peer to identify ourselves.
 */
static void send_hello(struct file_info *fi){
    //printf("DEBUG: send_hello : begin\n");
    char buffer[64];
    sprintf(buffer, "H%s:%d\n", inet_ntoa(my_addr.sin_addr), ntohs(my_addr.sin_port));
    file_info_send(fi, buffer, strlen(buffer));
}

/* This function is invoked in response to a non-blocking socket
 * connect() call once an outgoing connection is established or fails.
 */
static void connect_handler(struct file_info *fi, int events){
    //printf("DEBUG: connect_handler : begin\n");
    char buf[512];

    if (events & (POLLERR | POLLHUP)) {
        double time;
        int error;
        socklen_t len = sizeof(error);
        if (getsockopt(fi->fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
            perror("getsockopt");
        }
        switch (error) {
        case 0:
            printf("No connection on socket %d\n", fi->fd);
            time = timer_now() + 3;
            break;
        case ETIMEDOUT:
            printf("Timeout on socket %d\n", fi->fd);
            time = fi->u.fi_outgoing.connect_time + 5;
            break;
        default:
            printf("Error '%s' on socket %d\n", strerror(error), fi->fd);
            time = timer_now() + 5;
        }

        /* Start a timer to reconnect.
         */
        timer_start(time, timer_reconnect, fi->uid);

        close(fi->fd);
        fi->fd = -1;
        fi->u.fi_outgoing.status = FI_CONNECTING;

        return;
    }
    if (events & POLLOUT) {
        printf("Socket %d connected\n", fi->fd);
        fi->handler = message_handler;
        fi->events = POLLIN;
        fi->u.fi_outgoing.status = FI_CONNECTED;

        send_hello(fi);
        gossip_to_peer(fi);
    }
    if (events & ~(POLLOUT|POLLERR|POLLHUP)) {
        printf("message_handler: unknown events %x\n", events);
        fi->events = 0;
    }
}

/* Invoke a non-blocking connect() to try and establish a connection.
 */
void try_connect(struct file_info *fi){
    //printf("DEBUG: try_connect : begin\n");
    int skt = socket(AF_INET, SOCK_STREAM, 0);
    if (skt < 0) {
        perror("try_connect: socket");
        return;
    }

    /* Make the socket, skt, non-blocking.
     */
    // YOUR CODE HERE
    fcntl(skt, F_SETFL, O_NONBLOCK); //SET TO NON BLOCKING

    if (connect(skt, (struct sockaddr *) &fi->addr, sizeof(fi->addr)) < 0) {
        printf("Connecting to %s:%d on socket %d\n", inet_ntoa(fi->addr.sin_addr), ntohs(fi->addr.sin_port), skt);
        if (errno != EINPROGRESS) {
            perror("try_connect: connect");
            close(skt);
            return;
        }

        fi->fd = skt;
        fi->events = POLLOUT;
        fi->handler = connect_handler;
        fi->u.fi_outgoing.connect_time = timer_now();
    }
    else {
        printf("Connected to %s:%d on socket %d\n", inet_ntoa(fi->addr.sin_addr), ntohs(fi->addr.sin_port), skt);
        fi->fd = skt;
        fi->events = POLLIN;
        fi->handler = message_handler;
        fi->u.fi_outgoing.connect_time = timer_now();
        fi->u.fi_outgoing.status = FI_CONNECTED;
    }
}

/* Standard input is available.
 */
static void stdin_handler(struct file_info *fi, int events){
    //printf("DEBUG: stdin_handler : begin\n");
    if (events & POLLIN) {
        add_input(fi);
    }
    if (events & ~POLLIN) {
        fprintf(stderr, "input_handler: unknown events %x\n", events);
    }
}

/* Activity on the server socket.  Typically an incoming connection.
 * Accept the connection and create a new file_info descriptor for it.
 */
static void server_handler(struct file_info *fi, int events){
    //printf("DEBUG: server_handler : begin\n");
    if (events & POLLIN) {
        struct sockaddr_in addr;
        socklen_t len = sizeof(addr);
        int skt = accept(fi->fd, (struct sockaddr *) &addr, &len);
        if (skt < 0) {
            perror("accept");
        }

        /* Make the socket non-blocking.
         */
        // YOUR CODE HERE
        fcntl(skt, F_SETFL, O_NONBLOCK); //SET TO NON BLOCKING

        /* Keep track of the socket.
         */
        struct file_info *fi = file_info_add(FI_INCOMING, skt, message_handler, POLLIN);

        /* We don't know yet who's on the other side exactly until we
         * get the H(ello) message.  But for debugging it's convenient
         * to keep the peer's socket address.
         */
        fi->addr = addr;

        printf("New connection from %s:%d on socket %d\n", inet_ntoa(addr.sin_addr), ntohs(addr.sin_port), skt);

        send_hello(fi);
        gossip_to_peer(fi);
    }
    if (events & ~POLLIN) {
        fprintf(stderr, "server_handler: unknown events %x\n", events);
    }
}

/* Usage: a.out [port].  If no port is specified, a default port is used.
 */
int main(int argc, char *argv[]){
    int bind_port = argc > 1 ? atoi(argv[1]) : 0;
    int i;
    int enablesetsock = 1;
    
    //printf("DEBUG: main : starting program with port value %d\n", bind_port);
    /* Read from standard input.
     */
    struct file_info *input = file_info_add(FI_FILE, 0, stdin_handler, POLLIN);

    /* Create a TCP socket.
     */
    int skt;
    skt = socket(AF_INET, SOCK_STREAM, 0);
    //printf("DEBUG: main : socket created\n");
    if (setsockopt(skt, SOL_SOCKET, SO_REUSEADDR, &enablesetsock, sizeof(int)) < 0)
    perror("main : setsockopt(SO_REUSEADDR) failed");
    // YOUR CODE HERE

    /* Make the socket non-blocking.
     */
    fcntl(skt, F_SETFL, O_NONBLOCK); //SET TO NON BLOCKING
    // YOUR CODE HERE

    /* Initialize bind_addr in as far as possible.
     */
    struct sockaddr_in bind_addr;
    bzero((char *) &bind_addr, sizeof(bind_addr));
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(bind_port);
    bind_addr.sin_addr.s_addr = INADDR_ANY;
    // YOUR CODE HERE

    /* Bind the socket.
     */
    if (bind(skt, (struct sockaddr*) &bind_addr, sizeof(bind_addr)) < 0 ) {
        perror("main : cannot bind the socket");
    }
    //printf("DEBUG: main : bind success\n");
    // YOUR CODE HERE

    /* Keep track of the socket.
     */
    file_info_add(FI_SERVER, skt, server_handler, POLLIN);

    /* Get my address.
     */
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    if (getsockname(skt, (struct sockaddr *) &addr, &len) < 0) {
        perror("getsocknane");
    }

    /* Get my IP addresses.
     */
    struct ifaddrs *addr_list, *ifa;
    if (getifaddrs(&addr_list) < 0) {
        perror("getifaddrs");
        return 1;
    }
    for (ifa = addr_list; ifa != 0; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr != 0 && ifa->ifa_addr->sa_family == AF_INET &&
                !(ifa->ifa_flags & IFF_LOOPBACK)) {
            struct sockaddr_in *si = (struct sockaddr_in *) ifa->ifa_addr;
            printf("%s: %s:%d\n", ifa->ifa_name, inet_ntoa(si->sin_addr), ntohs(addr.sin_port));
            my_addr = *si;
            my_addr.sin_port = addr.sin_port;
        }
    }
    freeifaddrs(addr_list);

    /* Pretend standard input is a peer...
     */
    input->addr = my_addr;
    input->status = FI_KNOWN;

    /* Listen on the socket.
     */
    if (listen(skt, 5) < 0) {
        perror("listen");
        return 1;
    }
    
    printf("> "); fflush(stdout);
    //printf("DEBUG: main : going in for loop\n");
    for (;;) {
        /* Handle expired timers first.
         */
        int timeout = timer_check();

        //printf("DEBUG: main : preparing for polling\n");
        /* Prepare poll.
         */
        struct pollfd *fds = calloc(nfiles, sizeof(*fds));
        struct file_info *fi, **fi_index = calloc(nfiles, sizeof(*fi_index));
        int i;
        for (i = 0, fi = file_info; fi != 0; fi = fi->next) {
            //printf("DEBUG: main : printing fi values : index = %d , fi->type %d , fi->events %d , fi->status %d\n", i, fi->type, fi->events, fi->status);
            if (fi->type != FI_FREE && fi->fd >= 0) {
                fds[i].fd = fi->fd;
                fds[i].events = fi->events;
                if (fi->amount_to_send > 0) {
                    //printf("DEBUG: main : amount to send for fi values : index = %d , fi->type %d , fi->events %d , fi->status %d\n", i, fi->type, fi->events, fi->status);
                    fds[i].events |= POLLOUT;
                }
                fi_index[i++] = fi;
            }
        }

        int n = i; // n may be less than nfiles
        if (poll(fds, n, timeout) < 0) {
            perror("poll");
            return 1;
        }

        /* See if there's activity on any of the files/sockets.
         */
        //printf("DEBUG: main : check if activity on any file/sockets\n");
        for (i = 0; i < n; i++) {
            if (fds[i].revents != 0 && fi_index[i]->type != FI_FREE) {
                //printf("DEBUG: main : found activity for index %d\n", i);
                (*fi_index[i]->handler)(fi_index[i], fds[i].revents);
            }
        }
        free(fds);
        free(fi_index);
        //printf("DEBUG: main : end of polling\n");
    }

    return 0;
}
