#include <arpa/inet.h>
#include <stdbool.h>
#define INFINITY		INT_MAX
#define UNDEFINED					(-1)
#define INDEX(x, y, nnodes)			((x) + (nnodes) * (y))

double timer_now(void);
void timer_start(double when, void (*handler)(void *arg), void *arg);
int timer_check(void);

extern struct sockaddr_in my_addr;
extern struct file_info *file_info;
//extern struct gossip *gossip;

//struct file_info;
struct file_info {
    struct file_info *next;                     // linked list management
    char *uid;                                  // unique connection id
    int fd;                                     // file descriptor
    enum file_info_type {
        FI_FREE,                            // unused entry
        FI_FILE,                            // file descriptor, probably stdin
        FI_SERVER,                          // server socket
        FI_INCOMING,                        // incoming connection
        FI_OUTGOING,                        // outgoing connection
    } type;                                     // type of file
    enum { FI_UNKNOWN, FI_KNOWN } status;       // is the peer address known?
    struct sockaddr_in addr;                    // address of peer if known
    void (*handler)(struct file_info *, int events);        // event handler`
    int events;                                 // POLLIN, POLLOUT
    char *input_buffer;                         // stuff received
    int amount_received;                        // size of input buffer
    char *output_buffer;                        // stuff to send
    int amount_to_send;                         // size of output buffer
    union {
        struct fi_outgoing {
            enum { FI_CONNECTING, FI_CONNECTED } status;
            double connect_time;            // time of last attempt to connect
        } fi_outgoing;
    } u;
};

//network structure
struct network_struct {
    struct node_list *nodeList;
    int *dist;
    int *graph;
    int *prev;
} networkStructure;

struct sockaddr_in;
struct gossip;
struct node_list;

void gossip_to_peer(struct file_info *fi);
void gossip_received(struct file_info *fi, char *line);
struct gossip* gossip_next(struct gossip* gossip);
struct sockaddr_in gossip_src(struct gossip* gossip);
char* gossip_latest(struct gossip* gossip);

void file_info_send(struct file_info *fi, char *buf, int size);
void file_broadcast(char *buf, int size, struct file_info *fi);
struct file_info* sockaddr_to_file(struct sockaddr_in dst);

int addr_get(struct sockaddr_in *sin, const char *addr, int port);
int addr_cmp(struct sockaddr_in a1, struct sockaddr_in a2);

void send_received(char *line);

//functions from linkstate.c
struct node_list *nl_create(void);
int nl_nsites(struct node_list *nl);
void nl_add(struct node_list *nl, char *node);
int nl_compare(const void *e1, const void *e2);
void nl_sort(struct node_list *nl);
int* nl_sort_output_indexes(struct node_list *nl, int *outSize);
int nl_index(struct node_list *nl, char *node);
char *nl_name(struct node_list *nl, int index);
void nl_destroy(struct node_list *nl);
void set_dist(struct node_list *nl, int graph[], int nnodes, char *src, char *dst, int dist);
char* addr_to_string(struct sockaddr_in addr);
struct sockaddr_in string_to_addr(char* string);
char **nl_get_nodes(struct node_list *nl);
void dijkstra(int graph[], int nnodes, int src, int dist[], int prev[]);
void recalculate_graph();
void create_graph();
void recreate_gossip_graph();
void parseNload_gossip_message(char *srcaddr, char *gossip_payload);
void update_nodeList(char *node, bool neighbor, bool nodereset);
void call_dijkstra();
void connection_change_handler();
