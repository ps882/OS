#include "global.h"
#include <assert.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdbool.h>

#define INFINITY                INT_MAX
#define UNDEFINED               (-1)
#define INDEX(x, y, nnodes)         ((x) + (nnodes) * (y))

int validateIP(char *ipadd){

    unsigned b1, b2, b3, b4, p5, p6;
    unsigned char c;
    
    if (sscanf(ipadd, "%3u.%3u.%3u.%3u:%u%c", &b1, &b2, &b3, &b4, &p5, &c) <= 4) return 0;
    //printf("values are %u,%u,%u,%u,%u,%c\n",b1,b2,b3,b4,p5,c);
    if ((b1 | b2 | b3 | b4) > 255) return 0;
    if (p5 > 65000 | p5 == 0) return 0;
    if (strspn(ipadd, "0123456789.:") < strlen(ipadd)) return 0;
    return 1;
}

struct node_list {
    char **nodes;
    int nnodes;
    int unsorted;
};

unsigned long Gcounter = 0;

//extern struct sockaddr_in my_addr;
//extern struct file_info *file_info;
extern struct gossip *gossip;
//define my network struct to store nodelist, distances and graph

/*struct network_struct {
    struct node_list *nodeList;
    int *dist;
    int *graph;
    int *prev;
} networkStructure;
*/

int nl_index(struct node_list *nl, char *node);

struct node_list *nl_create(void) {
    return (struct node_list *) calloc(1, sizeof(struct node_list));
}

int nl_nsites(struct node_list *nl){
    return nl->nnodes;
}

void nl_add(struct node_list *nl, char *node){
    /* No duplicate nodes.
     */
    if (nl_index(nl, node) != -1) {
        return;
    }
    /* Create a copy of the site.
     */
    int len = strlen(node);
    char *copy = malloc(len + 1);
    strcpy(copy, node);

    /* Add this copy to the list.
     */
    nl->nodes= (char **) realloc(nl->nodes, sizeof(char *) * (nl->nnodes + 1));
    nl->nodes[nl->nnodes++] = copy;
    nl->unsorted = 1;
}

int nl_compare(const void *e1, const void *e2){
    const char **p1 = (const char **) e1, **p2 = (const char **) e2;
    return strcmp(*p1, *p2);
}

void nl_sort(struct node_list *nl){
    qsort(nl->nodes, nl->nnodes, sizeof(char *), nl_compare);
    nl->unsorted = 0;
}

/* Return the rank of the given site in the given site list.
 */
int nl_index(struct node_list *nl, char *node){
    /* Sort the list if not yet sorted.
     */
    if (nl->unsorted) {
        nl_sort(nl);
    }

    /* Binary search.
     */
    int lb = 0, ub = nl->nnodes;
    while (lb < ub) {
        int i = (lb + ub) / 2;
        int cmp = strcmp(node, nl->nodes[i]);
        if (cmp < 0) {
            ub = i;
        }
        else if (cmp > 0) {
            lb = i + 1;
        }
        else {
            return i;
        }
    }
    return -1;
}

char *nl_name(struct node_list *nl, int index){
    if (index < 0) {
        return "UNDEFINED";
    }
    return nl->nodes[index];
}

void nl_destroy(struct node_list *nl){
    int i;

    for (i = 0; i < nl->nnodes; i++) {
        free(nl->nodes[i]);
    }
    free(nl->nodes);
    free(nl);
}

/* Set the distance from src to dst.
 */
void set_dist(struct node_list *nl, int graph[], int nnodes, char *src, char *dst, int dist){
    int x = nl_index(nl, src), y = nl_index(nl, dst);
    if (x < 0 || y < 0) {
        fprintf(stderr, "set_dist: bad source or destination\n");
        return;
    }
    graph[INDEX(x, y, nnodes)] = dist;
    graph[INDEX(y, x, nnodes)] = dist;
}

char* addr_to_string (struct sockaddr_in addr) {
    char* addr_string = malloc(40);
    strcpy(addr_string, inet_ntoa(addr.sin_addr));
    strcat(addr_string, ":");
    char* port = malloc(12);
    sprintf(port, "%d", ntohs(addr.sin_port));
    strcat(addr_string, port);
    free(port);
    return addr_string;
}

struct sockaddr_in string_to_addr(char* string) {
    char *port = index(string, ':');
    *port++ = '\0';
    
    struct sockaddr_in addr;
    memset((void*)&addr, 0, sizeof(addr));
    addr_get(&addr, string, atoi(port));
    *--port = ':';
    return addr;
}


/*************************************************
    Dijkstra's algorithm
*************************************************/

/* Dijkstra's algorith.  graph[INDEX(x, y, nnodes)] contains the
 * distance of node x to node y.  nnodes is the number of nodes.  src
 * is that starting node.  Output dist[x] gives the distance from src
 * to x.  Output prev[x] gives the last hop from src to x.
 */
void dijkstra(int graph[], int nnodes, int src, int dist[], int prev[]){
    //printf("DEBUG: dijkstra : begin\n");
    //printf("DEBUG: dijkstra : nnodes = %d , src = %d , actnnode = %d\n",nnodes, src, networkStructure.nodeList->nnodes);
    int *visitedNodes = calloc(nnodes, sizeof(int));
    int i , j;

    // Initialize the graph given to distance and previous nodes

    for (i = 0; i < nnodes; i++){
        dist[i] = INFINITY;
        prev[i] = UNDEFINED;
        visitedNodes[i] = 0;  //calloc will have already initialized the memory cells 0
        if (i == src){
            dist[src] = 0; //set the self distance to 0
        }
    }

    //Run the dijkstra's algorithm repeatedly as many times as there are nnodes sequentially

    for (i = 0; i < nnodes; i++){

        // get the unvisited node with min cost node to update its neighbour's distance from src

        int minCost = INFINITY;
        int minIndex = UNDEFINED;

        // iterate through nodes in graphs to find the one with min cost to src eg, initially it will be src and then next and so on

        for (j = 0; j < nnodes; j++){
            if ( (visitedNodes[j] == 0) && dist[j] < minCost ){
                minCost = dist[j];
                minIndex = j;
            }
        }

        //Now we have our unvisited minimum cost and index from source

        if (minIndex == UNDEFINED ){

            //printf("DEBUG: dijkstra : no unvisited neighbor or non-short path\n");
            //if no unvisited neighbour with lesser cost then graph has already converged so exit

            break;
        }
        else {

            //mark it as visited and recalculate its neighbours' cost from src

            //printf("DEBUG: dijkstra : no unvisited neighbor or non-short path\n");
            visitedNodes[minIndex] = 1;

        }
        //check all the connected neighbors of the unvisited node and compute and update minimum distance

        for (j = 0; j < nnodes; j++){
            //printf("DEBUG: dijkstra : checking for neighbor node j=%d for minindex node\n",j);
            if ( visitedNodes[j] == 1){
                //printf("DEBUG: dijkstra : %d is a visited node\n",j);
                continue;
            }

            //printf("DEBUG: dijkstra : value of graph1 = %d , graph2 = %d and dist[j] = %d, new dist = %d\n", graph[INDEX(minIndex, j, nnodes)], graph[INDEX(j, minIndex, nnodes)], dist[j], graph[INDEX(minIndex, j, nnodes)] + minCost);
            if ( graph[INDEX(minIndex, j, nnodes)] != INFINITY &&  graph[INDEX(j, minIndex, nnodes)] != INFINITY &&  dist[j] >  graph[INDEX(minIndex, j, nnodes)] + minCost ){
                //printf("DEBUG: dijkstra : minimizing j = %d, minCost = %d, minIndex = %d\n",j,minCost, minIndex);
                dist[j] = graph[INDEX(minIndex, j, nnodes)] + minCost;
                prev[j] = minIndex;
                //printf("DEBUG: dijkstra : minimized dist to j = %d, prev of j = %d\n",dist[j], prev[j]);
            }
        }
    }
    free(visitedNodes);

    //debug section// print everything
    for (i=0; i<nnodes; i++){
        for (j=0; j <nnodes; j++){
            //printf("DEBUG: dijkstra : i = %d , j = %d , index value at %d = %d\n", i, j, INDEX(i , j , nnodes), graph[INDEX(i , j , nnodes)]);
        }
    }

    for (i=0; i < nnodes; i++){
        //printf("DEBUG: dijkstra : index is %d , nodename is %s, previous node is %d, previous nodename is %s, dist is %d\n", i,nl_name(networkStructure.nodeList,i),networkStructure.prev[i],nl_name(networkStructure.nodeList,networkStructure.prev[i]), networkStructure.dist[i]);
    }

}

//-------------------------node list add-----------------------------

//this function will add given node to the nodeList and call graph function to create or do recalculation.
//if new node is a neighbor then it willset the graph distance as 1

void update_nodeList(char *node, bool neighbor, bool nodereset){
    //printf("DEBUG: update_nodeList : begin\n");

    int i;
// if nodeList is not created already create it now

    if (networkStructure.nodeList == 0){
        //printf("DEBUG: update_nodeList: nodelist is not created yet\n");
        networkStructure.nodeList = nl_create();
        if (networkStructure.nodeList == 0){
            fprintf(stderr, "update_nodeList(): cannot create network structure for addition of new node\n");
            return;
        }
        //once nodeList is created, add yourself and new new node received to it
        nl_add(networkStructure.nodeList, addr_to_string(my_addr));
        nl_add(networkStructure.nodeList, node);
        //and create graph
        create_graph();
    }
    //if nodeList exist but new node does not exist

    else if(nl_index(networkStructure.nodeList , node) == -1 ){
        //add new node in it and recalculate graph
        nl_add(networkStructure.nodeList , node);
        recalculate_graph();

        if (neighbor){
            set_dist(networkStructure.nodeList, networkStructure.graph, networkStructure.nodeList->nnodes, addr_to_string(my_addr), node, 1);
//            set_dist(networkStructure.nodeList, networkStructure.graph, networkStructure.nodeList->nnodes, node, addr_to_string(my_addr), 1);
        }
    }
    //if nodeList exist and newly given node also exist then check if need to reset the distances (to be done when connection lost/ganied)
    else if(nodereset){
        int nodeIndex = nl_index(networkStructure.nodeList, node);
        //for this node set all distances to INFINITY
        for (i = 0; i < networkStructure.nodeList->nnodes; i++){
            networkStructure.graph[INDEX(nodeIndex, i, networkStructure.nodeList->nnodes)] = INFINITY;
        }
    }
    //if reset is also not to be done check if neighbor and set distance accordingly
    else if (neighbor){
            set_dist(networkStructure.nodeList, networkStructure.graph, networkStructure.nodeList->nnodes, addr_to_string(my_addr), node, 1);
//            set_dist(networkStructure.nodeList, networkStructure.graph, networkStructure.nodeList->nnodes, node, addr_to_string(my_addr), 1);
    }
        
}
//this function will do the graph recalculation after every node addition in nodeList
void recalculate_graph(){
    //printf("DEBUG: recalculate_graph : begin\n");
    int i, j, nnode = networkStructure.nodeList->nnodes;
    int *recal_graph = malloc(nnode * nnode * sizeof(int));
    
    for (i = 0; i < nnode; i++){

        if (i == nnode - 1){
        //if source node is new node then set the graph values to INFINITY
            for (j = 0; j < nnode; j++){
                recal_graph[INDEX(i , j , nnode)] = INFINITY;
            }
        }

        else {
            for (j = 0; j < nnode; j++){
                if (j == nnode - 1){
                //if destination node is new node then set the graph values to INFINITY
                    recal_graph[INDEX(i , j , nnode)] = INFINITY;
                }
                else {
                    recal_graph[INDEX(i , j , nnode)] = networkStructure.graph[INDEX(i , j , nnode-1)];
                }
            }
        }
    }

    free(networkStructure.graph);
    networkStructure.graph = recal_graph;
}


//this node will handle creation of graph when there is none already// called by update_nodelist()
void create_graph(){
    //printf("DEBUG: create_graph : begin\n");
    int i, self_index = nl_index(networkStructure.nodeList, addr_to_string(my_addr));
    struct file_info *fi;

    //check in file descriptor for any connected incoming and outgoing connection and ensure that they are added

    for ( fi = file_info; fi != 0; fi = fi->next) {
        if ( (fi->u.fi_outgoing.status == FI_CONNECTED && fi->status == FI_KNOWN && fi->type == FI_OUTGOING) || (fi->type == FI_INCOMING) )  {
            char *neighboraddr = addr_to_string(fi->addr);
            nl_add(networkStructure.nodeList, neighboraddr);
            free(neighboraddr);
        }
    }

    //initialize the memory for storing graph

    int nnode = networkStructure.nodeList->nnodes;
    networkStructure.graph = malloc(nnode * nnode * sizeof(int));

    //assign infinity to all the nodes in graph

    for ( i = 0 ; i < nnode * nnode ; i++){
        networkStructure.graph[i] = INFINITY;
    }

    //rewrite the distances between yourself and other nodes as 1, since no prior node/graph exist only neighbors are connected
    
    for (i = 0; i < nnode; i++){
        networkStructure.graph[INDEX(self_index , i , nnode)] = 1;
        networkStructure.graph[INDEX(i , self_index , nnode)] = 1;
    }
    networkStructure.graph[INDEX(self_index , self_index , nnode)] = 0;
}

//this function will parse and load the information in payload to graph and nodelist
void parseNload_gossip_message(char *srcaddr, char *gossip_payload){
    //printf("DEBUG: parseNload_gossip_message : begin\n");
    //target is to update the source node in gossip message and all the payloads too
    char *pointer, savedchar;

    update_nodeList(srcaddr, false, true);

    //iterate through the payload until the pointer for index ; hits null

    while (pointer != 0){
        //if at ; then move ahead to first char of address
        if (gossip_payload[0] == ';'){
            gossip_payload++;
        }
        //if payload ends here then exit from this function
        if (gossip_payload[0] == '\0'){
            return;
        }

        //look for next ; to find where the address ends 
        //if found then replace with \0 temporarily to extract just one address value
        //else consider it as last address value in payload and proceed
        pointer = index(gossip_payload,';');
        if (pointer != 0){
            savedchar = pointer[0];
            pointer[0] = '\0';}

        //if address retrieved is valid add it in nodeList and set distance as well
        if (validateIP(gossip_payload)){
//            printf("final address is %s\n",gossip_payload);
            update_nodeList(gossip_payload, false, false);
            set_dist(networkStructure.nodeList, networkStructure.graph, networkStructure.nodeList->nnodes, srcaddr, gossip_payload,1);
        }
        if (pointer != 0){
            pointer[0] = savedchar;
        }
        //move on to next address in payload and repeat
        gossip_payload = index(gossip_payload,';');
    }
}

//this function deals with connections changes and calls appropriate functions needed
void connection_change_handler(){
    //printf("DEBUG: connection_change_handler : begin\n");
    struct file_info *fi;
    int num_neighbor = 10 , i = 0;
    char *outgossip = (char *)malloc(num_neighbor * 22 * sizeof(char));
    char *pointer;

    //initialize the gossip message

    sprintf(outgossip, "G%s/%lu/;", addr_to_string(my_addr), Gcounter );

    //set the pointer to the end of message, we will append payload after it

    pointer = index(outgossip,';');

    //clear all distances from my node to all other nodes// will create fresh

    update_nodeList(addr_to_string(my_addr), false, true);

    //loop through file handler and do 1) add the node to nodeList and 2) add the node address to outgossip

    for (fi = file_info ; fi != 0; fi = fi->next){

        if (fi->type == FI_INCOMING || (fi->type == FI_OUTGOING && fi->u.fi_outgoing.status == FI_CONNECTED) ){
            //printf("DEBUG: connection_change_handler : found a neighbor IN/OUT\n");
            size_t len_addr = strlen(addr_to_string(fi->addr));
            update_nodeList(addr_to_string(fi->addr), true, false);
            i++;

            //if number of neighbors more than current neighbors, double numneighbor

            if (i >= num_neighbor){
                //printf("DEBUG: connection_change_handler : exceeded no. of default neighbor\n");
                num_neighbor *= 2;
                outgossip = realloc(outgossip, num_neighbor * 22 * sizeof(char));
                pointer = rindex(outgossip,';');
            }

            //copy the address followed by ; and move pointer position accordingly

            memcpy(++pointer, addr_to_string(fi->addr), len_addr );
            pointer = pointer + len_addr;
            memcpy(pointer, (char *)";", (size_t)1);
//            //printf("DEBUG: connection_change_handler : pre char sending payload %s\n",outgossip);
        }
    }

    //end the outgossip with newline char and \0 to end the string

    memcpy(++pointer, (char *)"\n", (size_t)1);
    memcpy(++pointer, (char *)"\0", (size_t)1);
    //printf("DEBUG: connection_change_handler : sending payload %s\n",outgossip);
    //printf("DEBUG: connection_change_handler: value of size %d\n",(int)(pointer - outgossip));

    file_broadcast(outgossip, (int)(pointer - outgossip), NULL);
    Gcounter++;
    call_dijkstra();

    //broadcast the formatted gossip to your neighbors and increment the counter

    free(outgossip);
}


//this function will initialize/reallocate dist and prev and call dijkstra
void call_dijkstra(){
    //printf("DEBUG: call_dijsktra : begin\n");
    int nnode = nl_nsites(networkStructure.nodeList);
    if (networkStructure.dist != 0){
        free(networkStructure.dist);
    }
        networkStructure.dist = (int *)malloc(nnode * sizeof(int));

    if (networkStructure.prev != 0){
        free(networkStructure.prev);
    }
        networkStructure.prev = (int *)malloc(nnode * sizeof(int));

    dijkstra(networkStructure.graph, nnode, nl_index(networkStructure.nodeList, addr_to_string(my_addr)), networkStructure.dist, networkStructure.prev );
}


//
